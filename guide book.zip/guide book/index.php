<!DOCTYPE html>
<html class="wide wow-animation" lang="en">

<head>
    <title>Home</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <script src="/cdn-cgi/apps/head/3ts2ksMwXvKRuG480KNifJ2_JNM.js"></script>
    <link rel="icon" href="images/favicon.ico" type="image/x-icon">
    <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Oswald:200,300,400,500,700%7CMontserrat:400,500,600">
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/fonts.css">
    <link rel="stylesheet" href="css/style.css">
	<script src="https://kit.fontawesome.com/1fb451dce7.js" crossorigin="anonymous"></script>
    <style>
        .ie-panel {
            display: none;
            background: #212121;
            padding: 10px 0;
            box-shadow: 3px 3px 5px 0 rgba(0, 0, 0, .3);
            clear: both;
            text-align: center;
            position: relative;
            z-index: 1;
        }

        html.ie-10 .ie-panel,
        html.lt-ie-10 .ie-panel {
            display: block;
        }
    </style>
</head>

<body>
    <div class="ie-panel"><a href="https://windows.microsoft.com/en-US/internet-explorer/"><img src="images/ie8-panel/warning_bar_0000_us.jpg" height="42" width="820" alt="You are using an outdated browser. For a faster, safer browsing experience, upgrade for free today."></a></div>
    <div class="preloader">
        <div class="preloader-body">
            <div class="cssload-container">
                <div class="cssload-speeding-wheel"></div>
            </div>
            <p>Loading...</p>
        </div>
    </div>
    <div class="page">
        <header class="section page-header">
            <!--RD Navbar-->
            <div class="rd-navbar-wrap">
                <nav class="rd-navbar rd-navbar-classic" data-layout="rd-navbar-fixed" data-sm-layout="rd-navbar-fixed" data-md-layout="rd-navbar-fixed" data-md-device-layout="rd-navbar-fixed" data-lg-layout="rd-navbar-static" data-lg-device-layout="rd-navbar-static"
                    data-xl-layout="rd-navbar-static" data-xl-device-layout="rd-navbar-static" data-lg-stick-up-offset="46px" data-xl-stick-up-offset="46px" data-xxl-stick-up-offset="46px" data-lg-stick-up="true" data-xl-stick-up="true" data-xxl-stick-up="true">
                    <div class="rd-navbar-collapse-toggle rd-navbar-fixed-element-1" data-rd-navbar-toggle=".rd-navbar-collapse"><span></span></div>
                    <div class="rd-navbar-main-outer">
                        <div class="rd-navbar-main">
                            <!--RD Navbar Panel-->
                            <div class="rd-navbar-panel">
                                <!--RD Navbar Toggle-->
                                <button class="rd-navbar-toggle" data-rd-navbar-toggle=".rd-navbar-nav-wrap"><span></span></button>
                                <!--RD Navbar Brand-->
                                <div class="rd-navbar-brand">
                                    <!--Brand--><h2 style="color:white">TOURIST GUIDE BOOK</h2>
                                </div>
                            </div>
                            <div class="rd-navbar-main-element">
                                <div class="rd-navbar-nav-wrap">
                                    <ul class="rd-navbar-nav">
                                        <li class="rd-nav-item active"><a class="rd-nav-link" href="index.php">Home</a> </li>
										
										    <li class="rd-nav-item"><a class="rd-nav-link" href="guide.php">Guide</a></li>
                                        
                                        <li class="rd-nav-item"><a class="rd-nav-link" href="user.php">User</a></li>
                                            
                                        
                                       
                                        </li>
                                    </ul>
                                </div>
                                <!--RD Navbar Search-->
                                <div class="rd-navbar-search">
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </nav>
            </div>
        </header>
        <!--Swiper-->
        <section class="section swiper-container swiper-slider swiper-slider-1" data-swiper='{"loop":"true","dataTouch":false,"autoplay":{"delay":5000}}'>
            <div class="swiper-wrapper text-center">
                <div class="swiper-slide context-dark" data-slide-bg="images/slider-1-slide-1.jpg">
                    <div class="swiper-slide-caption section-md">
                        <div class="container">
                            <div class="row justify-content-lg-center">
                                <div class="col-lg-8">
                                    <div class="intro-box">
                                        <div class="intro-box__floating-text">Journey</div>
                                        <div class="intro-box__title"><span data-caption-animate="fadeInUp" data-caption-delay="200">Exploring</span><span data-caption-animate="fadeInUp" data-caption-delay="300">the world</span></div>
                                        <div class="intro-box__video" data-caption-animate="fadeInUp" data-caption-delay="400"><a href="https://www.youtube.com/watch?v=7dTve2Hsl_0" data-lightgallery="item">Watch the video</a></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="swiper-slide context-dark" data-slide-bg="images/slider-1-slide-2.jpg">
                    <div class="swiper-slide-caption section-md">
                        <div class="container">
                            <div class="row justify-content-lg-center">
                                <div class="col-lg-8">
                                    <div class="intro-box">
                                        <div class="intro-box__floating-text">Journey</div>
                                        <div class="intro-box__title"><span data-caption-animate="fadeInUp" data-caption-delay="200">Best</span><span data-caption-animate="fadeInUp" data-caption-delay="300">Destinations</span></div>
                                        <div class="intro-box__video" data-caption-animate="fadeInUp" data-caption-delay="400"><a href="https://www.youtube.com/watch?v=7dTve2Hsl_0" data-lightgallery="item">Watch the video</a></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="swiper-slide context-dark" data-slide-bg="images/slider-1-slide-3.jpg">
                    <div class="swiper-slide-caption section-md">
                        <div class="container">
                            <div class="row justify-content-lg-center">
                                <div class="col-lg-8">
                                    <div class="intro-box">
                                        <div class="intro-box__floating-text">Journey</div>
                                        <div class="intro-box__title"><span data-caption-animate="fadeInUp" data-caption-delay="200">Memorable</span><span data-caption-animate="fadeInUp" data-caption-delay="300">Experiences</span></div>
                                        <div class="intro-box__video" data-caption-animate="fadeInUp" data-caption-delay="400"><a href="https://www.youtube.com/watch?v=7dTve2Hsl_0" data-lightgallery="item">Watch the video</a></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--Swiper Pagination-->
            <div class="swiper-pagination"></div>
            <!--Swiper Navigation-->
            <div class="swiper-button-prev fa-arrow-left"></div>
            <div class="swiper-button-next fa-arrow-right"></div>
        </section>
        <!--Way to Travel-->
        <section class="section section-custom-1 bg-image-1">
            <div class="container">
                <div class="row row-30">
                    <div class="col-xl-5">
                        <h2><span class="wow fadeInLeft d-xl-block">Explore a different</span><span class="wow fadeInLeft d-xl-block" data-wow-delay=".2s">way to travel</span></h2>
                        <p class="wow fadeInLeft offset-xl" data-wow-delay=".3s">Discover new cultures and have a wonderful rest with Backpack Story! Select the country you’d like to visit and provide our agents with estimated time – they’ll find and offer the most suitable tours and hotels.</p>
                        <p class="wow fadeInLeft" data-wow-delay=".4s">During our work, we organized countless journeys for our clients. We started as a small tour bureau, and soon we expanded our offers list. Today we have valuable experience travelling and we can advise the most stunning resorts,
                            cities and countries to visit!</p>
                        <div class="offset-top-25 wow fadeInUp" data-wow-delay=".5s"><img src="images/signature-1-113x66.png" alt="" width="113" height="66" />
                        </div>
                    </div>
                    <div class="col-xl-7">
                        <div class="image-box inset-xl-1 wow fadeInUp">
                            <div class="image-box__static"><img src="images/img-2-home-364x459.jpg" alt="" width="364" height="459" />
                            </div>
                            <div class="image-box__float"><img src="images/img-1-home-364x459.jpg" alt="" width="364" height="459" />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--Call to action creative-->
        <section class="section bg-image-2 section-lg">
            <div class="container">
                <div class="row row-30 flex-column-reverse flex-lg-row">
                    <div class="col-lg-4 d-flex flex-column justify-content-lg-center justify-content-xl-end wow fadeInLeft z-index align-items-center"><a class="floating-video-box" href="https://www.youtube.com/watch?v=7dTve2Hsl_0" data-lightgallery="item"><img src="images/video-overlay-370x288.jpg" alt="" width="370" height="288"/><span class="icon fa fa-play"></span></a></div>
                    <div class="col-lg-8 column-bg-1">
                        <div class="quote-classic-wrap">
                            <div class="heading-4 wow fadeInUp">At Backpack Story, we personally plan and create all our tours to offer flexibility and unique impressions that you won't get anywhere else. Moreover, each tour is tailor-made for our customers to provide the experience they
                                are looking for.</div>
                            <p class="font-italic wow fadeInUp" data-wow-delay=".2s">John Wilson, Agency director</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--Advantages-->
        <section class="section section-md bg-default">
            <div class="container">
                <div class="row row-30">
                    <div class="col-lg-4 wow fadeInUp" data-wow-delay=".2s">
                        <h2><a href="#">01. best Hotels</a></h2>
                        <p class="offset-xl">We guarantee the best hotels and very comfortable rooms, which will be appreciated by every traveller. You will be absolutely happy with the hotel and will have a wonderful vacation there.</p>
                    </div>
                    <div class="col-lg-4 wow fadeInUp" data-wow-delay=".3s">
                        <h2><a href="#">02. Tourist Guide</a></h2>
                        <p class="offset-xl">We provide our clients with such a service as Tourist Guide. Its main goal is to ensure people with all necessary information any time it's needed. This service is similar to Customer Support with emphasis on travelling.</p>
                    </div>
                    <div class="col-lg-4 wow fadeInUp" data-wow-delay=".4s">
                        <h2><a href="#">03. Flights Tickets</a></h2>
                        <p class="offset-xl">You can book tickets on any plane online via our booking system. Here you have an opportunity to select your transport operator. Our representatives will help you with the details.</p>
                    </div>
                </div>
            </div>
        </section>
        <!--Tours-->
        <section class="section section-lg bg-image-3">
            <div class="creative-bg">
                <div class="container">
                    <div class="row row-30 justify-content-center" data-lightgallery="group">
                        <div class="d-flex col-sm-6 col-lg-4 ordex-xl-1 order-1 wow fadeInLeft"><a class="info-box-classic" href="images/home-gallery-1-1200x800-original.jpg" data-lightgallery="item"><img src="images/home-gallery-1-370x510.jpg" alt="" width="370" height="510"/>
                  <div class="info-box-classic__description">
                    <div class="heading-4">Canada</div><span>from</span><span class="price">$540</span>
                  </div></a></div>
                        <div class="col-sm-12 col-lg-4 order-3 order-xl-2">
                            <div class="row row-30">
                                <div class="col-lg-12 col-sm-6 wow fadeInUp" data-wow-delay=".2s"><a class="info-box-classic" href="images/home-gallery-2-1200x800-original.jpg" data-lightgallery="item"><img src="images/home-gallery-2-370x240.jpg" alt="" width="370" height="240"/>
                      <div class="info-box-classic__description">
                        <div class="heading-4">India</div><span>from</span><span class="price">$330</span>
                      </div></a></div>
                                <div class="col-lg-12 col-sm-6 wow fadeInUp" data-wow-delay=".3s"><a class="info-box-classic" href="images/home-gallery-3-1200x800-original.jpg" data-lightgallery="item"><img src="images/home-gallery-3-370x240.jpg" alt="" width="370" height="240"/>
                      <div class="info-box-classic__description">
                        <div class="heading-4">China</div><span>from</span><span class="price">$500</span>
                      </div></a></div>
                            </div>
                        </div>
                        <div class="d-flex col-sm-6 col-lg-4 ordex-xl-3 order-md-2 wow fadeInRight" data-wow-delay=".4s"><a class="info-box-classic" href="images/home-gallery-4-1200x800-original.jpg" data-lightgallery="item"><img src="images/home-gallery-4-370x510.jpg" alt="" width="370" height="510"/>
                  <div class="info-box-classic__description">
                    <div class="heading-4">Paris</div><span>from</span><span class="price">$720</span>
                  </div></a></div>
                    </div>
                </div>
            </div>
        </section>
        <!--Info Section-->
        <section class="section section-md bg-default">
            <div class="container">
                <h2>Start your journey!</h2>
                <div class="row row-40 offset-lg">
                    <div class="col-xl-6 wow fadeInLeft">
                        <p>Let us curate an inspiring experience as you enjoy a personally-themed adventure with a professional guide catered to your interests. Whether a one-day trip or multi-trip journey, you’ll be privileged to enjoy this ultimate luxury
                            to explore Europe with an expert, as well as the unique bird’s eye views from a helicopter in Europe, including Rome, the Dalmation Coast, Paris, Prague and 20 top destinations.</p>
                    </div>
                    <div class="col-xl-3 col-sm-6 wow fadeInUp">
                        <ul class="list-marked">
                            <li>First-class flights</li>
                            <li>5-star accommodation</li>
                            <li>All-inclusive packages</li>
                            <li>Car hire</li>
                            <li>Handpicked hotels</li>
                        </ul>
                    </div>
                    <div class="col-xl-3 col-sm-6 wow fadeInUp">
                        <ul class="list-marked">
                            <li>Leisure travel</li>
                            <li>Travel insurance</li>
                            <li>Emergency services</li>
                            <li>Incentive programs</li>
                            <li>Visas</li>
                        </ul>
                    </div>
                </div>
            </div>
        </section>
        <section class="section section-lg bg-image-4">
            <div class="container">
                <div class="row justify-content-xl-end">
                    <div class="col-xl-9 column-bg-2">
                        <div class="quote-classic-wrap">
                            <div class="heading-4 wow fadeInUp">Our team makes every effort to deliver outstanding tour services for our numerous clients. With us, you can experience even the most exotic destinations in all their beauty.</div>
                            <p class="font-italic wow fadeInUp" data-wow-delay=".2s">Jane Peters, Tour consultant</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--Blog Post-->
        <section class="section section-lg">
            <div class="container">
                <h2 class="text-center text-md-left">Our blog posts</h2>
                <div class="row row-30">
                    <div class="col-lg-4 col-md-6">
                        <div class="post-classic"><a class="post-classic__media" href="#"><img src="images/blog-post-1-370x264.jpg" alt="" width="370" height="264"/></a>
                            <div class="post-classic-caption"><span>January 1, 2021</span>
                                <h5><a href="#">5 PLACES TO VISIT THIS WINTER</a></h5>
                                <p>New Year and Christmas holidays is a great occasion to travel somewhere. You can either go somewhere with you family or friends, or even alone....</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="post-classic"><a class="post-classic__media" href="#"><img src="images/blog-post-2-370x264.jpg" alt="" width="370" height="264"/></a>
                            <div class="post-classic-caption"><span>January 1, 2021</span>
                                <h5><a href="#">Budget Trips for Winter Break</a></h5>
                                <p>Budget trip doesn’t mean boring! There are numerous places worth visiting even if you don’t have much money. The golden sands of Florida and California...</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="post-classic"><a class="post-classic__media" href="#"><img src="images/blog-post-3-370x264.jpg" alt="" width="370" height="264"/></a>
                            <div class="post-classic-caption"><span>January 1, 2021</span>
                                <h5><a href="#">Walking to Machu Picchu, Peru</a></h5>
                                <p>Machu Picchu is mysterious and attractive place for all tourists visiting Peru. If you agree to take this path you need to know more information...</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--Footer-->
        <footer class="section footer-classic context-dark">
            <div class="container">
                <div class="row row-narrow-40 row-30">
                    <div class="col-lg-6 text-center wow fadeInLeft" data-wow-delay=".1s">
                        <div class="footer-media"><img src="images/footer-img-570x402.jpg" alt="" width="570" height="402" />
                        </div>
                    </div>
                    <div class="col-lg-6 wow fadeInRight" data-wow-delay=".2s">
                        <div class="footer-classic_subscribe">
                            <h2>Newsletter Signup</h2>
                            <h5 class="text-primary">SIGN UP NOW TO RECEIVE HOT SPECIAL OFFERS AND INFORMATION ABOUT THE BEST TOURS!</h5>
                            <form class="rd-form rd-mailform rd-form-inline subscribe-form" data-form-output="form-output-global" data-form-type="subscribe" method="post" action="bat/rd-mailform.php">
                                <div class="form-wrap">
                                    <input class="form-input" id="subscribe-form-email-5" type="email" name="email" data-constraints="@Email @Required">
                                    <label class="form-label" for="subscribe-form-email-5">Enter your e-mail</label>
                                    <div class="form-button">
                                        <button class="button button-primary fa fa-chevron-circle-right" type="submit"></button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="footer-classic-aside">
                <div class="container">
                    <div class="row justify-content-between flex-column-reverse flex-md-row row-20">
                        <div class="col-xl-6 col-md-8">
                            <div class="footer-classic-aside__group">
                                <!--Brand--><h2 style="color:white">TOURIST GUIDE BOOK</h2>
                                <p class="rights"><span>Copyright</span><span>&nbsp;</span><span>&copy;&nbsp;</span><span class="copyright-year"></span><span>&nbsp;</span><span>All Rights Reserved</span></p>
                            </div>
                        </div>
                        <div class="col-xl-3 col-md-4">
                            <ul class="social-list">
                                <li class="wow fadeInUp" data-wow-delay=".1s"><a href="#"><span class="icon fa fa-facebook"></span></a></li>
                                <li class="wow fadeInUp" data-wow-delay=".2s"><a href="#"><span class="icon fa fa-twitter"></span></a></li>
                                <li class="wow fadeInUp" data-wow-delay=".3s"><a href="#"><span class="icon fa fa-instagram"></span></a></li>
                                <li class="wow fadeInUp" data-wow-delay=".4s"><a href="#"><span class="icon fa fa-pinterest"></span></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
    </div>
    <div class="snackbars" id="form-output-global"></div>
    <script src="js/core.min.js"></script>
    <script src="js/script.js"></script>

    <!--LIVEDEMO_00 -->

    <script type="text/javascript">
        var _gaq = _gaq || [];
        _gaq.push(['_setAccount', 'UA-7078796-5']);
        _gaq.push(['_trackPageview']);
        (function() {
            var ga = document.createElement('script');
            ga.type = 'text/javascript';
            ga.async = true;
            ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'https://www') + '.google-analytics.com/ga.js';
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(ga, s);
        })();
    </script>

    <!-- Google Tag Manager --><noscript><iframe src="//www.googletagmanager.com/ns.html?id=GTM-P9FT69" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
    <script>
        (function(w, d, s, l, i) {
            w[l] = w[l] || [];
            w[l].push({
                'gtm.start': new Date().getTime(),
                event: 'gtm.js'
            });
            var f = d.getElementsByTagName(s)[0],
                j = d.createElement(s),
                dl = l != 'dataLayer' ? '&l=' + l : '';
            j.async = true;
            j.src = '//www.googletagmanager.com/gtm.js?id=' + i + dl;
            f.parentNode.insertBefore(j, f);
        })(window, document, 'script', 'dataLayer', 'GTM-P9FT69');
    </script>
    <!-- End Google Tag Manager -->
</body>

</html>