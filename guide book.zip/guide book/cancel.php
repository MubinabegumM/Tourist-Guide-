<?php
include("dbconnect.php");
session_start();
 
	
	$id=$_REQUEST['id'];
	
	$qy=mysqli_query($conn,"delete from booking1 where id='$id'");
if($qy){?>
	<script> alert('cancelled Successfully')
window.location.href=("mybook.php");</script>

<?php } ?>