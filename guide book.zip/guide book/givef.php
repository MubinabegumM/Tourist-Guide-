<?php
	session_start();
 	include("dbconnect.php");
	


  $name= $_SESSION['uid'];
echo  $wid=$_GET['gid'];
  
$qry=mysqli_query($conn,"select * from guides where id=$wid;");
extract($_POST);
if(isset($_POST['btn'])){
$rd=mysqli_fetch_array($qry);



$qry2=mysqli_query($conn,"insert into ratings values('','$wid','$rating','$emo','$feedback','$name')");

if($qry){?>
		 <script> alert('Thanks for your feedback')
window.location.href=("mybook.php");</script>
<?php } }?>


<!DOCTYPE html>
<html class="wide wow-animation" lang="en">

<head>
    <title>Home</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <script src="/cdn-cgi/apps/head/3ts2ksMwXvKRuG480KNifJ2_JNM.js"></script>
    <link rel="icon" href="images/favicon.ico" type="image/x-icon">
    <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Oswald:200,300,400,500,700%7CMontserrat:400,500,600">
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/fonts.css">
    <link rel="stylesheet" href="css/style.css">
	<script src="https://kit.fontawesome.com/1fb451dce7.js" crossorigin="anonymous"></script>
	    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/rateYo/2.3.2/jquery.rateyo.min.css">
    <style>
	
	
	  .ie-panel {
            display: none;
            background: #212121;
            padding: 10px 0;
            box-shadow: 3px 3px 5px 0 rgba(0, 0, 0, .3);
            clear: both;
            text-align: center;
            position: relative;
            z-index: 1;
        }

        html.ie-10 .ie-panel,
        html.lt-ie-10 .ie-panel {
            display: block;
        }
	
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f2f5;
    
        
        }

        .login-container {
            background-color: #fff;
            padding: 30px;
            border-radius: 20px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            width: 320px;
			margin:0 auto;
			
			
       
        }

        .login-container h1 {
            font-size: 24px;
            margin-bottom: 20px;
        }

        .input-group {
            margin-bottom: 20px;
        }

        .input-group label {
            display: block;
            
        }

        .input-group input,select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 10px;
            font-size: 16px;
        }

        .input-group input[type="submit"] {
            background-color: #1877f2;
            color: #fff;
            cursor: pointer;
			text-align:center;
		position:relative;
		left:10px;
			
        }

        .input-group input[type="submit"]:hover {
            background-color: #166fe5;
        }

        .forgot-password {
            color: #1877f2;
            text-decoration: none;
            font-size: 14px;
        }
		
		
		
		
		
		
		.main{
	  display:flex;
	  flex-wrap:wrap;
	  column-gap:50px;
	  row-gap:20px;
	  }
	  .main2{
	  display:flex;
	  flex-direction:column;
	  flex-wrap:wrap;
	  width:400px;
	  min-height:740px;
	  row-gap:5px;
	  padding:20px;
	  box-shadow:2px 2px  10px 2px lightgray;
	  margin-left:20px;
	  box-sizzing:border-box;
	  border-top-left-radius:10px;
	  border-top-right-radius:10px;
	  margin:0 auto;
	  text-align:center;
	  }
	 
	  .price{
	  
	
	  color:#FFFFFF;
	  font-weight:800;
	   background:#0033FF;
	  border-radius:5px;
	  width:100%;
	  padding:10px;
	  text-align:center;
	 }
	 .main2 img{
	width:100%;
	 height:200px;
	 }
	  .add{
	   padding:10px;
	  background:#0033FF;
	  color:#FFFFFF;
	  
	  font-weight:800;
	
	  border-radius:5px;
	    width:80%;
	  text-align:center;
	
	  margin-top:30px;
	  }
	  .add a{
	  text-decoration:none;
	  color:#FFF;
	  }
	  .123{
	  height:20px;
	  }
	  
}
.emo {
display:flex;
direction:row;
width:400px;
height:200px;
color:#FFFF00;

}
.emo img{
width:30px;
height:30px;
border-radius:50%;

}
.emo img:hover{
border:5px solid lightgray;
width:50px;
height:50px;
}
textarea{
border:1px solid black;
}
		
		
		
		
		
		
    </style>
</head>
</head>

<body>
    <div class="ie-panel"><a href="https://windows.microsoft.com/en-US/internet-explorer/"><img src="images/ie8-panel/warning_bar_0000_us.jpg" height="42" width="820" alt="You are using an outdated browser. For a faster, safer browsing experience, upgrade for free today."></a></div>
    <div class="preloader">
        <div class="preloader-body">
            <div class="cssload-container">
                <div class="cssload-speeding-wheel"></div>
            </div>
            <p>Loading...</p>
        </div>
    </div>
    <div class="page">
        <header class="section page-header">
            <!--RD Navbar-->
            <div class="rd-navbar-wrap">
                <nav class="rd-navbar rd-navbar-classic" data-layout="rd-navbar-fixed" data-sm-layout="rd-navbar-fixed" data-md-layout="rd-navbar-fixed" data-md-device-layout="rd-navbar-fixed" data-lg-layout="rd-navbar-static" data-lg-device-layout="rd-navbar-static"
                    data-xl-layout="rd-navbar-static" data-xl-device-layout="rd-navbar-static" data-lg-stick-up-offset="46px" data-xl-stick-up-offset="46px" data-xxl-stick-up-offset="46px" data-lg-stick-up="true" data-xl-stick-up="true" data-xxl-stick-up="true">
                    <div class="rd-navbar-collapse-toggle rd-navbar-fixed-element-1" data-rd-navbar-toggle=".rd-navbar-collapse"><span></span></div>
                    <div class="rd-navbar-main-outer">
                        <div class="rd-navbar-main">
                            <!--RD Navbar Panel-->
                            <div class="rd-navbar-panel">
                                <!--RD Navbar Toggle-->
                                <button class="rd-navbar-toggle" data-rd-navbar-toggle=".rd-navbar-nav-wrap"><span></span></button>
                                <!--RD Navbar Brand-->
                                <div class="rd-navbar-brand">
                                    <!--Brand--><h2 style="color:white">TOURISPHERE</h2>
                                </div>
                            </div>
                            <div class="rd-navbar-main-element">
                                <div class="rd-navbar-nav-wrap">
                                    <ul class="rd-navbar-nav">
                                        <li class="rd-nav-item active"><a class="rd-nav-link" href="guideview.php">Home</a> </li>
                                       
                                        <li class="rd-nav-item"><a class="rd-nav-link" href="mybook.php">View Bookings</a></li>
										
										
                                        
                                        <li class="rd-nav-item"><a class="rd-nav-link" href="index.php">Logout</a></li>
                      
                                    </ul>
                                </div>
                                <!--RD Navbar Search-->
                                <div class="rd-navbar-search">
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </nav>
            </div>
        </header>
        <!--Swiper-->
      
        <!--Way to Travel-->
   
        <!--Call to action creative-->
      
        <!--Tours-->
       <br /><br /><br /><br />
	<form action="" method="post" > 
<div class="main" >
	
	  <?php while($row=mysqli_fetch_array($qry)){ ?>
	    <div class="main2">
	  <img src="upload\<?php echo $row['img']; ?>" />
	  <p class="price"><?php echo $row['gname']; ?><p>
	  <h3 class="model">Location:   <?php echo $row['address']; ?></h3>
	  <h4>Give Star Ratings<h4/>
<div align="center" >
 
         <div class="rateyo" id= "rating"
         data-rateyo-rating="1"
         data-rateyo-num-stars="5"
         data-rateyo-score="3">
		    
         </div>
		  <span class='result' name="rating">0</span>
	
    <input type="hidden" name="rating" required>
 </div >
  <h4>Share your feelings<h4/>
 	<div class="emo">
     
            <a id="1" onClick="emoji(this.id)"><img src="images\cry.png"/></a>
            <a id="2" onClick="emoji(this.id)"><img src="images\1.jfif"/></a>
            <a id="3" onClick="emoji(this.id)"><img src="images\sad.png"/></a>
			<a id="4" onClick="emoji(this.id)"><img src="images\download.jfif"/></a>
            <a id="5" onClick="emoji(this.id)"><img src="images\smile.png"/></a>
      
		</div>
 <h4>Enter Your feedback<h4/>
		<textarea name="feedback"></textarea>
		 <input type="hidden" name="emo" required id="emoji">
		
		 <input type="submit" name="btn"  value="Send Feedback" class="add">
	  <?php } ?>
	  </div>
	  
	  </form>
	
 <br /><br /><br />
        <!--Info Section-->
       
        <!--Blog Post-->
       
        <!--Footer-->
    
    </div>
    <div class="snackbars" id="form-output-global"></div>
    <script src="js/core.min.js"></script>
    <script src="js/script.js"></script>

    <!--LIVEDEMO_00 -->

    <script type="text/javascript">
        var _gaq = _gaq || [];
        _gaq.push(['_setAccount', 'UA-7078796-5']);
        _gaq.push(['_trackPageview']);
        (function() {
            var ga = document.createElement('script');
            ga.type = 'text/javascript';
            ga.async = true;
            ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'https://www') + '.google-analytics.com/ga.js';
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(ga, s);
        })();
    </script>

    <!-- Google Tag Manager --><noscript><iframe src="//www.googletagmanager.com/ns.html?id=GTM-P9FT69" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
    <script>
        (function(w, d, s, l, i) {
            w[l] = w[l] || [];
            w[l].push({
                'gtm.start': new Date().getTime(),
                event: 'gtm.js'
            });
            var f = d.getElementsByTagName(s)[0],
                j = d.createElement(s),
                dl = l != 'dataLayer' ? '&l=' + l : '';
            j.async = true;
            j.src = '//www.googletagmanager.com/gtm.js?id=' + i + dl;
            f.parentNode.insertBefore(j, f);
        })(window, document, 'script', 'dataLayer', 'GTM-P9FT69');
    </script>
    <!-- End Google Tag Manager -->
	
	
	
	
	
	
	
	
	
	
	
	 <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/rateYo/2.3.2/jquery.rateyo.min.js"></script>
 
<script>
 
 
    $(function () {
        $(".rateyo").rateYo().on("rateyo.change", function (e, data) {
            var rating = data.rating;
            $(this).parent().find('.score').text('score :'+ $(this).attr('data-rateyo-score'));
            $(this).parent().find('.result').text('rating :'+ rating);
            $(this).parent().find('input[name=rating]').val(rating); //add rating value to input field
        });
    });
 
</script>
<script type="text/javascript">
  function emoji(id)
  {
      
	    document.getElementById("emoji").setAttribute('value',id);
  }
</script>
	
	
	
	
	
	
	
	
</body>

</html>