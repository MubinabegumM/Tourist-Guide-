<?php
include 'dbconnect.php'; // Adjust the include path as needed

$address = $_GET['address'];
$qry = mysqli_query($conn, "SELECT * FROM guides WHERE address='$address'");

$output = '';
while ($row = mysqli_fetch_array($qry)) {
   $output .= "
    <tr style='transition: all 0.3s ease; border-bottom: 1px solid #e0e0e0; background-color: #ffffff;' onmouseover='this.style.backgroundColor=\"#f8f9fa\"' onmouseout='this.style.backgroundColor=\"#ffffff\"'>
        <td width='6%' style='padding: 14px;'>&nbsp;</td>
        
        <td style='padding: 14px;'>
            <div align='center' style='color: #2c3e50; font-size: 14px; font-family: \"Segoe UI\", Arial, sans-serif;'>
                {$row['id']}
            </div>
        </td>
        
        <td style='padding: 14px;'>
            <div align='center' style='color: #2c3e50; font-size: 14px; font-family: \"Segoe UI\", Arial, sans-serif;'>
                {$row['gname']}
            </div>
        </td>
        
        <td style='padding: 14px;'>
            <div align='center' style='color: #2c3e50; font-size: 14px; font-family: \"Segoe UI\", Arial, sans-serif;'>
                {$row['amnt']}
            </div>
        </td>
        
        <td style='padding: 14px;'>
            <div align='center' style='color: #2c3e50; font-size: 14px; font-family: \"Segoe UI\", Arial, sans-serif;'>
                {$row['address']}
            </div>
        </td>
        
        <td style='padding: 14px;'>
            <div align='center' style='color: #2c3e50; font-size: 14px; font-family: \"Segoe UI\", Arial, sans-serif;'>
                {$row['place']}
            </div>
        </td>
        
        <td width='21%' style='padding: 14px;'>
            <div align='center'>
                <a href='book2.php?gid={$row['id']}&gp={$row['amnt']}' 
                   style='
                    color: #ffffff;
                    background-color: #4CAF50;
                    padding: 8px 16px;
                    text-decoration: none;
                    border-radius: 4px;
                    font-size: 14px;
                    font-family: \"Segoe UI\", Arial, sans-serif;
                    transition: background-color 0.3s ease;
                    display: inline-block;
                    box-shadow: 0 2px 4px rgba(0,0,0,0.1);'
                   onmouseover='this.style.backgroundColor=\"#45a049\"'
                   onmouseout='this.style.backgroundColor=\"#4CAF50\"'>
                    Book Guide
                </a>
            </div>
        </td>
        
        <td width='21%' style='padding: 14px;'>
            <div align='center'>
                <a href='ufeed.php?gid={$row['id']}'
                   style='
                    color: #ffffff;
                    background-color: #dc3545;
                    padding: 8px 16px;
                    text-decoration: none;
                    border-radius: 4px;
                    font-size: 14px;
                    font-family: \"Segoe UI\", Arial, sans-serif;
                    transition: background-color 0.3s ease;
                    display: inline-block;
                    box-shadow: 0 2px 4px rgba(0,0,0,0.1);'
                   onmouseover='this.style.backgroundColor=\"#c82333\"'
                   onmouseout='this.style.backgroundColor=\"#dc3545\"'>
                    View Feedbacks
                </a>
            </div>
        </td>
    </tr>";
}

echo $output;
?>
