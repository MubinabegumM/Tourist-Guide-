

<?php
 	include("dbconnect.php");
	extract($_POST);
	session_start();

if(isset($_POST['btn']))
{
$qry1=mysqli_query($conn,"select * from register where uname='$uname'");
$count=mysqli_num_rows($qry1);
if($count>0){                                                                                           
echo "<script>alert('username already taken')</script>";
}else{
$qry=mysqli_query($conn,"insert into register(name,gender,age,email,phone,address,uname,psw) values('$name','$gender','$age','$email','$phone','$address','$uname','$psw')");
	if($qry)
	{
	
	echo "<script>alert('Registered sucessfully')</script>";
	
	}
	
	
}

}

?>



<!DOCTYPE html>
<html class="wide wow-animation" lang="en">

<head>
    <title>Home</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <script src="/cdn-cgi/apps/head/3ts2ksMwXvKRuG480KNifJ2_JNM.js"></script>
    <link rel="icon" href="images/favicon.ico" type="image/x-icon">
    <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Oswald:200,300,400,500,700%7CMontserrat:400,500,600">
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/fonts.css">
    <link rel="stylesheet" href="css/style.css">
	<script src="https://kit.fontawesome.com/1fb451dce7.js" crossorigin="anonymous"></script>
    <style>
	
	
	  .ie-panel {
            display: none;
            background: #212121;
            padding: 10px 0;
            box-shadow: 3px 3px 5px 0 rgba(0, 0, 0, .3);
            clear: both;
            text-align: center;
            position: relative;
            z-index: 1;
        }

        html.ie-10 .ie-panel,
        html.lt-ie-10 .ie-panel {
            display: block;
        }
	
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f2f5;
    
        
        }

        .login-container {
            background-color: #fff;
            padding: 30px;
            border-radius: 20px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            width: 820px;
			margin:0 auto;
			
			
       
        }

        .login-container h1 {
            font-size: 24px;
            margin-bottom: 20px;
        }

        .input-group {
            margin-bottom: 20px;
        }

        .input-group label {
            display: block;
            
        }

        .input-group input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 10px;
            font-size: 16px;
        }
		
		.input-group textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 10px;
            font-size: 16px;
        }

        .input-group input[type="submit"] {
            background-color: #1877f2;
            color: #fff;
            cursor: pointer;
			text-align:center;
		position:relative;
		left:10px;
			
        }

        .input-group input[type="submit"]:hover {
            background-color: #166fe5;
        }

        .forgot-password {
            color: #1877f2;
            text-decoration: none;
            font-size: 14px;
        }
    </style>
</head>
</head>

<body>
    <div class="ie-panel"><a href="https://windows.microsoft.com/en-US/internet-explorer/"><img src="images/ie8-panel/warning_bar_0000_us.jpg" height="42" width="820" alt="You are using an outdated browser. For a faster, safer browsing experience, upgrade for free today."></a></div>
    <div class="preloader">
        <div class="preloader-body">
            <div class="cssload-container">
                <div class="cssload-speeding-wheel"></div>
            </div>
            <p>Loading...</p>
        </div>
    </div>
    <div class="page">
        <header class="section page-header">
            <!--RD Navbar-->
            <div class="rd-navbar-wrap">
                <nav class="rd-navbar rd-navbar-classic" data-layout="rd-navbar-fixed" data-sm-layout="rd-navbar-fixed" data-md-layout="rd-navbar-fixed" data-md-device-layout="rd-navbar-fixed" data-lg-layout="rd-navbar-static" data-lg-device-layout="rd-navbar-static"
                    data-xl-layout="rd-navbar-static" data-xl-device-layout="rd-navbar-static" data-lg-stick-up-offset="46px" data-xl-stick-up-offset="46px" data-xxl-stick-up-offset="46px" data-lg-stick-up="true" data-xl-stick-up="true" data-xxl-stick-up="true">
                    <div class="rd-navbar-collapse-toggle rd-navbar-fixed-element-1" data-rd-navbar-toggle=".rd-navbar-collapse"><span></span></div>
                    <div class="rd-navbar-main-outer">
                        <div class="rd-navbar-main">
                            <!--RD Navbar Panel-->
                            <div class="rd-navbar-panel">
                                <!--RD Navbar Toggle-->
                                <button class="rd-navbar-toggle" data-rd-navbar-toggle=".rd-navbar-nav-wrap"><span></span></button>
                                <!--RD Navbar Brand-->
                                <div class="rd-navbar-brand">
                                    <!--Brand--><h2 style="color:white">TOURIST GUIDE BOOK</h2>
                                </div>
                            </div>
                            <div class="rd-navbar-main-element">
                                <div class="rd-navbar-nav-wrap">
                                    <ul class="rd-navbar-nav">
                                        <li class="rd-nav-item "><a class="rd-nav-link" href="index.php">Home</a> </li>
										
										    <li class="rd-nav-item"><a class="rd-nav-link" href="guide.php">Guide</a></li>
                                        
                                        <li class="rd-nav-item active"><a class="rd-nav-link" href="user.php">User</a></li>
                      
                                    </ul>
                                </div>
                                <!--RD Navbar Search-->
                                <div class="rd-navbar-search">
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </nav>
            </div>
        </header>
        <!--Swiper-->
        <section class="section swiper-container swiper-slider swiper-slider-1" data-swiper='{"loop":"true","dataTouch":false,"autoplay":{"delay":5000}}'>
            <div class="swiper-wrapper text-center">
                <div class="swiper-slide context-dark" data-slide-bg="images/slider-1-slide-1.jpg">
                    <div class="swiper-slide-caption section-md">
                        <div class="container">
                            <div class="row justify-content-lg-center">
                                <div class="col-lg-8">
                                    <div class="intro-box">
                                        <div class="intro-box__floating-text">Journey</div>
                                        <div class="intro-box__title"><span data-caption-animate="fadeInUp" data-caption-delay="200">Exploring</span><span data-caption-animate="fadeInUp" data-caption-delay="300">the world</span></div>
                                        <div class="intro-box__video" data-caption-animate="fadeInUp" data-caption-delay="400"><a href="https://www.youtube.com/watch?v=7dTve2Hsl_0" data-lightgallery="item">Watch the video</a></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="swiper-slide context-dark" data-slide-bg="images/slider-1-slide-2.jpg">
                    <div class="swiper-slide-caption section-md">
                        <div class="container">
                            <div class="row justify-content-lg-center">
                                <div class="col-lg-8">
                                    <div class="intro-box">
                                        <div class="intro-box__floating-text">Journey</div>
                                        <div class="intro-box__title"><span data-caption-animate="fadeInUp" data-caption-delay="200">Best</span><span data-caption-animate="fadeInUp" data-caption-delay="300">Destinations</span></div>
                                        <div class="intro-box__video" data-caption-animate="fadeInUp" data-caption-delay="400"><a href="https://www.youtube.com/watch?v=7dTve2Hsl_0" data-lightgallery="item">Watch the video</a></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="swiper-slide context-dark" data-slide-bg="images/slider-1-slide-3.jpg">
                    <div class="swiper-slide-caption section-md">
                        <div class="container">
                            <div class="row justify-content-lg-center">
                                <div class="col-lg-8">
                                    <div class="intro-box">
                                        <div class="intro-box__floating-text">Journey</div>
                                        <div class="intro-box__title"><span data-caption-animate="fadeInUp" data-caption-delay="200">Memorable</span><span data-caption-animate="fadeInUp" data-caption-delay="300">Experiences</span></div>
                                        <div class="intro-box__video" data-caption-animate="fadeInUp" data-caption-delay="400"><a href="https://www.youtube.com/watch?v=7dTve2Hsl_0" data-lightgallery="item">Watch the video</a></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--Swiper Pagination-->
            <div class="swiper-pagination"></div>
            <!--Swiper Navigation-->
            <div class="swiper-button-prev fa-arrow-left"></div>
            <div class="swiper-button-next fa-arrow-right"></div>
        </section>
        <!--Way to Travel-->
   
        <!--Call to action creative-->
      
        <!--Tours-->
		
		



       <br /><br /><br /><br />
	
    <div class="login-container">
        <h1>User Registration</h1>
        <form  method="POST">
            <div class="input-group">
                <label for="email">Name</label>
                <input type="text" placeholder="Enter  Name"  name="name" required>
            </div>
			<p>Choose Gender</p>
            <div class="input-group">
                <label for="password"></label>
                <div style="display:flex;justify-content:space-around;width:100%;border:1px solid #ccc;padding:10px 20px;border-radius:10px;"><input name="gender" type="radio" value="male"  required/>
        Male
          <input name="gender" type="radio" value="female" /> 
          Female</div>
            </div>
			
			
			 <div class="input-group">
                <label for="email">Age</label>
                <input type="text" placeholder="Enter  Age"  name="age" required>
            </div>
			
			
			 <div class="input-group">
                <label for="email">Email Id</label>
                <input type="email" placeholder="Enter  Email"  name="email" required>
            </div>
			
			
			
			<div class="input-group">
                <label for="email">Phone Number</label>
                <input type="text" placeholder="Enter  Number"  name="phone" required>
            </div>
			
			
			
			<div class="input-group">
                <label for="email">Address</label>
                <textarea placeholder="Enter  Address"  name="address" required></textarea>
            </div>
			
			
			<div class="input-group">
                <label for="email">Username</label>
                <input type="text" placeholder="Enter Usename"  name="uname" required>
            </div>
			
			
			
			<div class="input-group">
                <label for="email">Password</label>
                <input type="text" placeholder="Enter Password"  name="psw" required>
            </div>
			
			
			
            <div class="input-group">
                <input type="submit" value="Submit" name="btn">
				
            </div>
           <a href="user.php" style="color:#1877f2;margin-left:360px;">Login Now</a>
        </form>
    </div>
 <br /><br /><br />
        <!--Info Section-->
       
        <!--Blog Post-->
       
        <!--Footer-->
        <footer class="section footer-classic context-dark" >
            <div class="container" >
                <div class="row row-narrow-40 row-30"  >
                    <div class="col-lg-6 text-center wow fadeInLeft" data-wow-delay=".1s" ">
                        <div class="footer-media" style="box-shadow: 0px 0px white"><img src="images/video-overlay-370x288.jpg" alt="" width="400" height="402"  style="position:relative;top:100px;"/>
                        </div>
                    </div>
                    <div class="col-lg-6 wow fadeInRight" data-wow-delay=".2s">
                        <div class="footer-classic_subscribe">
                            <h2>Newsletter Signup</h2>
                            <h5 class="text-primary">SIGN UP NOW TO RECEIVE HOT SPECIAL OFFERS AND INFORMATION ABOUT THE BEST TOURS!</h5>
                            <form class="rd-form rd-mailform rd-form-inline subscribe-form" data-form-output="form-output-global" data-form-type="subscribe" method="post" action="bat/rd-mailform.php">
                                <div class="form-wrap">
                                    <input class="form-input" id="subscribe-form-email-5" type="email" name="email" data-constraints="@Email @Required">
                                    <label class="form-label" for="subscribe-form-email-5">Enter your e-mail</label>
                                    <div class="form-button">
                                        <button class="button button-primary fa fa-chevron-circle-right" type="submit"></button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="footer-classic-aside">
                <div class="container">
                    <div class="row justify-content-between flex-column-reverse flex-md-row row-20">
                        <div class="col-xl-6 col-md-8">
                            <div class="footer-classic-aside__group">
                                <!--Brand--><h2 style="color:white">TOURIST GUIDE BOOK</h2>
                                <p class="rights"><span>Copyright</span><span>&nbsp;</span><span>&copy;&nbsp;</span><span class="copyright-year"></span><span>&nbsp;</span><span>All Rights Reserved</span></p>
                            </div>
                        </div>
                        <div class="col-xl-3 col-md-4">
                            <ul class="social-list">
                                <li class="wow fadeInUp" data-wow-delay=".1s"><a href="#"><span class="icon fa fa-facebook"></span></a></li>
                                <li class="wow fadeInUp" data-wow-delay=".2s"><a href="#"><span class="icon fa fa-twitter"></span></a></li>
                                <li class="wow fadeInUp" data-wow-delay=".3s"><a href="#"><span class="icon fa fa-instagram"></span></a></li>
                                <li class="wow fadeInUp" data-wow-delay=".4s"><a href="#"><span class="icon fa fa-pinterest"></span></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
    </div>
    <div class="snackbars" id="form-output-global"></div>
    <script src="js/core.min.js"></script>
    <script src="js/script.js"></script>

    <!--LIVEDEMO_00 -->

    <script type="text/javascript">
        var _gaq = _gaq || [];
        _gaq.push(['_setAccount', 'UA-7078796-5']);
        _gaq.push(['_trackPageview']);
        (function() {
            var ga = document.createElement('script');
            ga.type = 'text/javascript';
            ga.async = true;
            ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'https://www') + '.google-analytics.com/ga.js';
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(ga, s);
        })();
    </script>

    <!-- Google Tag Manager --><noscript><iframe src="//www.googletagmanager.com/ns.html?id=GTM-P9FT69" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
    <script>
        (function(w, d, s, l, i) {
            w[l] = w[l] || [];
            w[l].push({
                'gtm.start': new Date().getTime(),
                event: 'gtm.js'
            });
            var f = d.getElementsByTagName(s)[0],
                j = d.createElement(s),
                dl = l != 'dataLayer' ? '&l=' + l : '';
            j.async = true;
            j.src = '//www.googletagmanager.com/gtm.js?id=' + i + dl;
            f.parentNode.insertBefore(j, f);
        })(window, document, 'script', 'dataLayer', 'GTM-P9FT69');
    </script>
    <!-- End Google Tag Manager -->
</body>

</html>